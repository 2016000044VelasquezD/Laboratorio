﻿namespace Laboratorio_1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox11 = new TextBox();
            textBox10 = new TextBox();
            label11 = new Label();
            label10 = new Label();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            button3 = new Button();
            button2 = new Button();
            button4 = new Button();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            dataGridView1 = new DataGridView();
            Clave = new DataGridViewTextBoxColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Apellido = new DataGridViewTextBoxColumn();
            Grado = new DataGridViewTextBoxColumn();
            Seccion = new DataGridViewTextBoxColumn();
            Direccion = new DataGridViewTextBoxColumn();
            Celular = new DataGridViewTextBoxColumn();
            Numero_de_matricula = new DataGridViewTextBoxColumn();
            Ciclo_Academico_Actual = new DataGridViewTextBoxColumn();
            Cumpleaños = new DataGridViewTextBoxColumn();
            Estado_Academico = new DataGridViewTextBoxColumn();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // textBox11
            // 
            textBox11.Location = new Point(359, 205);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(100, 23);
            textBox11.TabIndex = 51;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(359, 176);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(100, 23);
            textBox10.TabIndex = 50;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(240, 208);
            label11.Name = "label11";
            label11.Size = new Size(107, 15);
            label11.TabIndex = 49;
            label11.Text = "Estado_Academico";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(240, 179);
            label10.Name = "label10";
            label10.Size = new Size(74, 15);
            label10.TabIndex = 48;
            label10.Text = "Cumpleaños";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(178, 406);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(100, 23);
            textBox9.TabIndex = 47;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(178, 379);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 46;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(114, 345);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 45;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(114, 316);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 44;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(34, 411);
            label9.Name = "label9";
            label9.Size = new Size(138, 15);
            label9.TabIndex = 43;
            label9.Text = "Ciclo_Academico_Actual";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(48, 382);
            label8.Name = "label8";
            label8.Size = new Size(124, 15);
            label8.TabIndex = 42;
            label8.Text = "Numero_de_matricula";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(48, 353);
            label7.Name = "label7";
            label7.Size = new Size(44, 15);
            label7.TabIndex = 41;
            label7.Text = "Celular";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(48, 324);
            label6.Name = "label6";
            label6.Size = new Size(57, 15);
            label6.TabIndex = 40;
            label6.Text = "Direccion";
            // 
            // button3
            // 
            button3.Location = new Point(403, 408);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 39;
            button3.Text = "Borrar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(565, 407);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 38;
            button2.Text = "Editar ";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button4
            // 
            button4.Location = new Point(484, 406);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 37;
            button4.Text = "Guardar ";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(114, 287);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 36;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(114, 258);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 35;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(114, 229);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 34;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(114, 200);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(100, 23);
            textBox12.TabIndex = 33;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(114, 171);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(100, 23);
            textBox13.TabIndex = 32;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(48, 295);
            label5.Name = "label5";
            label5.Size = new Size(48, 15);
            label5.TabIndex = 31;
            label5.Text = "Seccion";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 266);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 30;
            label4.Text = "Grado";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(48, 237);
            label12.Name = "label12";
            label12.Size = new Size(36, 15);
            label12.TabIndex = 29;
            label12.Text = "Clave";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(48, 208);
            label13.Name = "label13";
            label13.Size = new Size(51, 15);
            label13.TabIndex = 28;
            label13.Text = "Apellido";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(48, 174);
            label14.Name = "label14";
            label14.Size = new Size(51, 15);
            label14.TabIndex = 27;
            label14.Text = "Nombre";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Clave, Nombre, Apellido, Grado, Seccion, Direccion, Celular, Numero_de_matricula, Ciclo_Academico_Actual, Cumpleaños, Estado_Academico });
            dataGridView1.Location = new Point(34, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(639, 150);
            dataGridView1.TabIndex = 26;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Clave
            // 
            Clave.HeaderText = "Clave";
            Clave.Name = "Clave";
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.Name = "Nombre";
            // 
            // Apellido
            // 
            Apellido.HeaderText = "Apellido";
            Apellido.Name = "Apellido";
            // 
            // Grado
            // 
            Grado.HeaderText = "Grado";
            Grado.Name = "Grado";
            // 
            // Seccion
            // 
            Seccion.HeaderText = "Seccion";
            Seccion.Name = "Seccion";
            // 
            // Direccion
            // 
            Direccion.HeaderText = "Direccion";
            Direccion.Name = "Direccion";
            // 
            // Celular
            // 
            Celular.HeaderText = "Celular";
            Celular.Name = "Celular";
            // 
            // Numero_de_matricula
            // 
            Numero_de_matricula.HeaderText = "Numero_de_matricula";
            Numero_de_matricula.Name = "Numero_de_matricula";
            // 
            // Ciclo_Academico_Actual
            // 
            Ciclo_Academico_Actual.HeaderText = "Ciclo_Academico_Actual";
            Ciclo_Academico_Actual.Name = "Ciclo_Academico_Actual";
            // 
            // Cumpleaños
            // 
            Cumpleaños.HeaderText = "Cumpleaños";
            Cumpleaños.Name = "Cumpleaños";
            // 
            // Estado_Academico
            // 
            Estado_Academico.HeaderText = "Estado_Academico";
            Estado_Academico.Name = "Estado_Academico";
            // 
            // button1
            // 
            button1.Location = new Point(646, 408);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 52;
            button1.Text = "Creditos";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(864, 516);
            Controls.Add(button1);
            Controls.Add(textBox11);
            Controls.Add(textBox10);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button4);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox12);
            Controls.Add(textBox13);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(dataGridView1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox11;
        private TextBox textBox10;
        private Label label11;
        private Label label10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Button button3;
        private Button button2;
        private Button button4;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox12;
        private TextBox textBox13;
        private Label label5;
        private Label label4;
        private Label label12;
        private Label label13;
        private Label label14;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Clave;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Apellido;
        private DataGridViewTextBoxColumn Grado;
        private DataGridViewTextBoxColumn Seccion;
        private DataGridViewTextBoxColumn Direccion;
        private DataGridViewTextBoxColumn Celular;
        private DataGridViewTextBoxColumn Numero_de_matricula;
        private DataGridViewTextBoxColumn Ciclo_Academico_Actual;
        private DataGridViewTextBoxColumn Cumpleaños;
        private DataGridViewTextBoxColumn Estado_Academico;
        private Button button1;
    }
}